# store_simple.py - place some simple data in a ZODB

from myzodb import MyZODB, transaction
db = MyZODB('./Data.fs')
dbroot = db.dbroot
dbroot['a_number'] = 3
dbroot['a_string'] = 'Gift'
dbroot['a_list'] = [1, 2, 3, 5, 7, 12]
dbroot['a_dictionary'] = { 1918: 'Red Sox', 1919: 'Reds' }
dbroot['deeply_nested'] = {
    1918: [ ('Red Sox', 4), ('Cubs', 2) ],
    1919: [ ('Reds', 5), ('White Sox', 3) ],
    }
transaction.commit()
db.close()
