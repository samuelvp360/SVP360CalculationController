from ZEO.ClientStorage import ClientStorage
from ZODB import DB

class MyRemoteZODB(object):
    def __init__(self, server, port):
        server_and_port = (server, port)
        self.storage = ClientStorage(server_and_port)
        self.db = DB(self.storage)
        self.connection = self.db.open()
        self.dbroot = self.connection.root()

    def close(self):
        self.connection.close()
        self.db.close()
        self.storage.close()

mydb = MyRemoteZODB('localhost', 8080)
dbroot = mydb.dbroot
